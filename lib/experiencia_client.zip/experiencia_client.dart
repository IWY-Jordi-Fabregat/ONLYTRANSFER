import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'dart:convert';
import 'dart:math'; 
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_stripe/flutter_stripe.dart' as stripe; 

// --- COLORS CORPORATIUS ONLYTRANSFER ---
const Color colorFonsBlanc = Colors.white;
const Color colorTaronjaVIP = Color(0xFFFF700A);
const Color colorGrisClar = Color(0xFF778591);
const Color colorGrisFosc = Color(0xFF556677);
const Color colorGrisNegre = Color(0xFF2D3142);
const Color colorGrisClarBackground = Color(0xFFF0F2F5);

class ExperienciaClient extends StatefulWidget {
  const ExperienciaClient({super.key});
  @override
  State<ExperienciaClient> createState() => _ExperienciaClientState();
}

class _ExperienciaClientState extends State<ExperienciaClient> {
  int _pasActual = 0; 
  bool _processant = false;
  Map<String, dynamic>? _reservaConsultada;
  String? _reservaSeleccionadaId; 
  
  // CONTROLADORS
  final TextEditingController _origenController = TextEditingController();
  final TextEditingController _destiController = TextEditingController();
  final TextEditingController _volController = TextEditingController();
  final TextEditingController _paxController = TextEditingController(text: '1');
  final TextEditingController _maletesController = TextEditingController(text: '0');
  final TextEditingController _nomClientController = TextEditingController();
  final TextEditingController _dniClientController = TextEditingController();
  final TextEditingController _mailClientController = TextEditingController();
  final TextEditingController _cercaCodiController = TextEditingController();

  DateTime _selectedDate = DateTime.now().add(const Duration(days: 1));
  TimeOfDay _selectedTime = const TimeOfDay(hour: 12, minute: 0);

  String _generarCodiReservaNetejat() {
    const String alfabetNet = 'BCDFGHJKLMNPQRSTVWXYZ23456789'; 
    return List.generate(6, (index) => alfabetNet[Random().nextInt(alfabetNet.length)]).join();
  }

  void _anarAConductors() {
    setState(() => _pasActual = 7); 
  }

  Future<void> _buscarReserva() async {
    String codi = _cercaCodiController.text.trim().toUpperCase();
    if (codi.isEmpty) return;
    setState(() => _processant = true);
    try {
      final query = await FirebaseFirestore.instance
          .collection('reserves')
          .where('codi_reserva', isEqualTo: codi)
          .limit(1)
          .get();

      if (query.docs.isNotEmpty) {
        setState(() {
          _reservaSeleccionadaId = query.docs.first.id;
          _reservaConsultada = query.docs.first.data();
          _pasActual = 6; 
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Codi no trobat."), backgroundColor: Colors.red));
      }
    } finally { setState(() => _processant = false); }
  }

  Future<void> _actualitzarEstatViatge(String id, String nouEstat) async {
    await FirebaseFirestore.instance.collection('reserves').doc(id).update({'estat_servei': nouEstat});
    final doc = await FirebaseFirestore.instance.collection('reserves').doc(id).get();
    setState(() { _reservaConsultada = doc.data(); });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: colorFonsBlanc,
      appBar: AppBar(
        flexibleSpace: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onDoubleTap: _anarAConductors,
          child: Container(color: Colors.transparent),
        ),
        title: const Column(mainAxisSize: MainAxisSize.min, children: [
          Text('ONLY TRANSFER', style: TextStyle(color: colorGrisNegre, letterSpacing: 2, fontSize: 14, fontWeight: FontWeight.bold)),
          Text('LUXURY TRANSPORT', style: TextStyle(fontSize: 8, color: colorTaronjaVIP, letterSpacing: 1)),
        ]),
        backgroundColor: colorFonsBlanc, elevation: 0, centerTitle: true,
        leading: _pasActual > 0 
            ? IconButton(icon: const Icon(Icons.arrow_back_ios, size: 18, color: colorGrisNegre), onPressed: () => setState(() { _pasActual = 0; _reservaSeleccionadaId = null; })) 
            : null,
      ),
      body: _construirPasActual(),
    );
  }

  Widget _construirPasActual() {
    switch (_pasActual) {
      case 0: return _pantallaSeleccio();
      case 1: return _pantallaDetalls();
      case 3: return _pantallaIdentificacio();
      case 4: return _pantallaGracies();
      case 5: return _pantallaCercarCodi();
      case 6: return _pantallaResultatCerca();
      case 7: return _pantallaGestioConductor();
      case 8: return _pantallaDetallViatgeConductor();
      default: return _pantallaSeleccio();
    }
  }

  // --- PANTALLES CONDUCTOR ---
  Widget _pantallaGestioConductor() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('reserves').where('estat_servei', whereIn: ['assignat', 'en camí', 'arribat', 'client a bord']).snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        var reserves = snapshot.data!.docs;
        return Column(children: [
          const Padding(padding: EdgeInsets.all(20), child: Text("SERVEIS ASSIGNATS", style: TextStyle(fontWeight: FontWeight.bold))),
          Expanded(child: ListView.builder(
            itemCount: reserves.length,
            itemBuilder: (context, index) {
              var doc = reserves[index];
              var res = doc.data() as Map<String, dynamic>;
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                color: colorGrisClarBackground,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  title: Text(res['client'] ?? 'Client', style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text("${res['hora']} - ${res['origen']}"),
                  onTap: () { setState(() { _reservaSeleccionadaId = doc.id; _reservaConsultada = res; _pasActual = 8; }); },
                ),
              );
            },
          )),
          _botoGris("SORTIR", Icons.exit_to_app, () => setState(() => _pasActual = 0)),
          const SizedBox(height: 20),
        ]);
      },
    );
  }

  Widget _pantallaDetallViatgeConductor() {
    if (_reservaConsultada == null) return _pantallaGestioConductor();
    String estat = _reservaConsultada!['estat_servei'] ?? 'assignat';
    return Padding(padding: const EdgeInsets.all(25), child: Column(children: [
      const Text("CONTROL DE VIATGE", style: TextStyle(fontWeight: FontWeight.bold, color: colorTaronjaVIP)),
      const SizedBox(height: 20),
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: colorGrisClarBackground, borderRadius: BorderRadius.circular(15)),
        child: Column(children: [
          _filaResum(Icons.person, "Client", _reservaConsultada!['client']),
          const Divider(),
          _filaResum(Icons.location_on, "Recollida", _reservaConsultada!['origen']),
          const Divider(),
          _filaResum(Icons.flag, "Destí", _reservaConsultada!['desti']),
        ]),
      ),
      const SizedBox(height: 40),
      if (estat == 'assignat') _botoAccio("ESTIC EN CAMÍ", () => _actualitzarEstatViatge(_reservaSeleccionadaId!, 'en camí')),
      if (estat == 'en camí') _botoAccio("HE ARRIBAT", () => _actualitzarEstatViatge(_reservaSeleccionadaId!, 'arribat')),
      if (estat == 'arribat') _botoAccio("CLIENT A BORD", () => _actualitzarEstatViatge(_reservaSeleccionadaId!, 'client a bord')),
      if (estat == 'client a bord') _botoAccio("FINALITZAR SERVEI", () { _actualitzarEstatViatge(_reservaSeleccionadaId!, 'finalitzat'); setState(() => _pasActual = 7); }),
      const SizedBox(height: 20),
      _botoGris("TORNAR", Icons.list, () => setState(() => _pasActual = 7)),
    ]));
  }

  // --- PANTALLES CLIENT ---
  Widget _pantallaSeleccio() {
    return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.airplanemode_active, color: colorTaronjaVIP, size: 40),
      const SizedBox(height: 60),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 40), child: _botoAccio("NOVA RESERVA", () => setState(() => _pasActual = 1))),
      const SizedBox(height: 15),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 40), child: _botoGris("CONSULTAR RESERVA", Icons.search, () => setState(() => _pasActual = 5))),
    ]));
  }

  Widget _pantallaResultatCerca() {
    if (_reservaConsultada == null) return _pantallaSeleccio();
    return SingleChildScrollView(padding: const EdgeInsets.all(25), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text("DETALLS DE LA RESERVA", style: TextStyle(color: colorTaronjaVIP, fontWeight: FontWeight.bold, fontSize: 12)),
      const SizedBox(height: 20),
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: colorGrisClarBackground, borderRadius: BorderRadius.circular(15)),
        child: Column(children: [
          _filaResum(Icons.info_outline, "Estat", _reservaConsultada!['estat_servei'].toUpperCase()),
          const Divider(),
          _filaResum(Icons.access_time, "Hora", _reservaConsultada!['hora'] ?? '-'),
          const Divider(),
          _filaResum(Icons.location_on_outlined, "Recollida", _reservaConsultada!['origen'] ?? '-'),
          const Divider(),
          _filaResum(Icons.flag_outlined, "Destí", _reservaConsultada!['desti'] ?? '-'),
          const Divider(),
          _filaResum(Icons.flight_takeoff, "Vol / Tren", _reservaConsultada!['vol_tren'] ?? '-'),
          const Divider(),
          _filaResum(Icons.people_outline, "Pax", _reservaConsultada!['pax']?.toString() ?? '1'),
        ]),
      ),
      const SizedBox(height: 30),
      _botoGris("TORNAR", Icons.home, () => setState(() => _pasActual = 0)),
    ]));
  }

  // --- AUXILIARS ---
  Widget _pantallaDetalls() { return SingleChildScrollView(padding: const EdgeInsets.all(25), child: Column(children: [ _campPredictiu(_origenController, "Recollida", Icons.location_on_outlined), const SizedBox(height: 15), _campPredictiu(_destiController, "Destinació", Icons.flag_outlined), const SizedBox(height: 15), _campBlanc(_volController, "Vol / Tren", Icons.flight_takeoff), const SizedBox(height: 15), Row(children: [ Expanded(child: _campBlanc(_paxController, "Pax", Icons.people_outline, esNumber: true)), const SizedBox(width: 10), Expanded(child: _campBlanc(_maletesController, "Maletes", Icons.luggage_outlined, esNumber: true))]), const SizedBox(height: 30), _botoAccio("CONTINUAR", () => setState(() => _pasActual = 3)) ])); }
  Widget _pantallaIdentificacio() { return SingleChildScrollView(padding: const EdgeInsets.all(25), child: Column(children: [ _campBlanc(_nomClientController, "Nom", Icons.person_outline), const SizedBox(height: 15), _campBlanc(_mailClientController, "Email", Icons.alternate_email), const SizedBox(height: 30), Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: colorGrisClarBackground, borderRadius: BorderRadius.circular(12)), child: stripe.CardFormField(style: stripe.CardFormStyle(fontSize: 14))), const SizedBox(height: 30), _processant ? const CircularProgressIndicator() : _botoAccio("PAGAR ARA", _executarPagamentDirecte) ])); }
  Widget _pantallaGracies() { return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [ const Icon(Icons.check_circle_outline, color: colorTaronjaVIP, size: 80), const Text("PAGAMENT COMPLETAT"), _botoGris("TORNAR", Icons.home, () => setState(() => _pasActual = 0)) ])); }
  Widget _pantallaCercarCodi() { return Padding(padding: const EdgeInsets.all(30), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [ const Text("ENTRA EL CODI DE RESERVA", style: TextStyle(color: colorTaronjaVIP, fontWeight: FontWeight.bold)), const SizedBox(height: 20), _campBlanc(_cercaCodiController, "Ex: 67GCRY", Icons.vpn_key_outlined), const SizedBox(height: 30), _processant ? const CircularProgressIndicator() : _botoAccio("BUSCAR", _buscarReserva) ])); }

  Future<void> _executarPagamentDirecte() async { setState(() => _processant = true); try { _gravarReservaAFirebase(); } catch (e) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e"))); } finally { setState(() => _processant = false); } }
  void _gravarReservaAFirebase() { String c = _generarCodiReservaNetejat(); FirebaseFirestore.instance.collection('reserves').add({ 'client': _nomClientController.text, 'codi_reserva': c, 'email': _mailClientController.text, 'origen': _origenController.text, 'desti': _destiController.text, 'vol_tren': _volController.text, 'pax': _paxController.text, 'hora': '12:00', 'data': '12/04/2026', 'estat_servei': 'pendent_assignar', 'creat_el': FieldValue.serverTimestamp() }); setState(() => _pasActual = 4); }

  Widget _filaResum(IconData icon, String titol, String valor) { return Row(children: [Icon(icon, size: 18, color: colorGrisFosc), const SizedBox(width: 15), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(titol.toUpperCase(), style: const TextStyle(fontSize: 9, color: colorGrisFosc, fontWeight: FontWeight.bold)), Text(valor ?? '-', style: const TextStyle(fontSize: 13, color: colorGrisNegre, fontWeight: FontWeight.w500))]))]); }
  Widget _campPredictiu(TextEditingController ctrl, String hint, IconData icon) { return TypeAheadField<String>(suggestionsCallback: (p) async { if (p.length < 3) return []; const String k = "AIzaSyA3yvNuaRTFJgRcRK0m5eu8_1cMquTRKrM"; final u = "https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$p&key=$k&language=en"; final r = await http.get(Uri.parse(u)); if (r.statusCode == 200) { final d = json.decode(r.body); return (d['predictions'] as List).map((i) => i['description'] as String).toList(); } return []; }, onSelected: (s) => setState(() => ctrl.text = s), itemBuilder: (c, s) => ListTile(title: Text(s, style: const TextStyle(fontSize: 12))), builder: (c, ct, f) { if (ct.text != ctrl.text) ct.text = ctrl.text; return TextField(controller: ct, focusNode: f, decoration: _estilInput(hint, icon)); }); }
  Widget _campBlanc(TextEditingController ctrl, String hint, IconData icon, {bool esNumber = false}) { return TextField(controller: ctrl, keyboardType: esNumber ? TextInputType.number : TextInputType.text, decoration: _estilInput(hint, icon)); }
  InputDecoration _estilInput(String hint, IconData icon) { return InputDecoration(filled: true, fillColor: colorGrisClarBackground, prefixIcon: Icon(icon, color: colorGrisFosc, size: 18), hintText: hint, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)); }
  Widget _botoGris(String text, IconData icon, VoidCallback onTap) { return GestureDetector(onTap: onTap, child: Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: colorGrisClarBackground, borderRadius: BorderRadius.circular(12)), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 16, color: colorGrisFosc), const SizedBox(width: 8), Text(text, style: const TextStyle(fontSize: 12))]))); }
  Widget _botoAccio(String text, VoidCallback onTap) { return SizedBox(width: double.infinity, height: 50, child: ElevatedButton(onPressed: onTap, style: ElevatedButton.styleFrom(backgroundColor: colorTaronjaVIP, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: Text(text, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)))); }
  void _triarData() async { DateTime? p = await showDatePicker(context: context, initialDate: _selectedDate, firstDate: DateTime.now(), lastDate: DateTime(2030)); if (p != null) setState(() => _selectedDate = p); }
  void _triarHora() async { TimeOfDay? p = await showTimePicker(context: context, initialTime: _selectedTime); if (p != null) setState(() => _selectedTime = p); }
}
